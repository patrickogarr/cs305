package com.snhu.sslserver;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import java.security.MessageDigest;

@RestController
public class HashController {

    @GetMapping("/hash")
    public String getChecksum() throws Exception {
        String data = "Hello World Check Sum!";
        String name = "Patrick Ogarr"; 

        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        byte[] hash = digest.digest(data.getBytes("UTF-8"));

        StringBuilder hexString = new StringBuilder();
        for (int i = 0; i < hash.length; i++) {
            String hex = Integer.toHexString(0xff & hash[i]);
            if(hex.length() == 1) hexString.append('0');
            hexString.append(hex);
        }

        return "Name: " + name + "<br>Data: " + data + "<br>Checksum (SHA-256): " + hexString.toString();
    }
}
